import { NgModule } from '@angular/core';
import { ToastUiImageEditorComponent } from './toast-ui-image-editor.component';

@NgModule({
  imports: [],
  declarations: [ToastUiImageEditorComponent],
  exports: [ToastUiImageEditorComponent]
})
export class ToastUiImageEditorModule {}
