import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { HttpClient } from '@angular/common/http';
import { interval, Subscription } from 'rxjs';

declare var require: any;
let Boost = require('highcharts/modules/boost');
let noData = require('highcharts/modules/no-data-to-display');
let More = require('highcharts/highcharts-more');


Boost(Highcharts);
noData(Highcharts);
More(Highcharts);
noData(Highcharts);

@Component({
  selector: 'app-output-graph',
  templateUrl: './output-graph.component.html',
  styleUrls: ['./output-graph.component.css']
})
export class OutputGraphComponent implements OnInit {
  public options: any = {
    chart: {
      type: 'spline'
  },
  title: {
      text: 'Monthly Average Temperature'
  },
  subtitle: {
      text: 'Source: WorldClimate.com'
  },
  xAxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
  },
  yAxis: {
      title: {
          text: 'Temperature'
      },
      labels: {
          formatter: function () {
              return this.value + '°';
          }
      }
  },
  tooltip: {
      crosshairs: true,
      shared: true
  },
  plotOptions: {
      spline: {
          marker: {
              radius: 4,
              lineColor: '#666666',
              lineWidth: 1
          }
      }
  },
  series: [{
      name: 'Tokyo',
      marker: {
          symbol: 'square'
      },
      data: [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, {
          y: 26.5,
          marker: {
              symbol: 'url(https://www.highcharts.com/samples/graphics/sun.png)'
          }
      }, 23.3, 18.3, 13.9, 9.6]

    }, 
    {
      name: 'London',
      marker: {
          symbol: 'diamond'
      },
      data: [{
          y: 3.9,
          marker: {
              symbol: 'url(https://www.highcharts.com/samples/graphics/snow.png)'
          }
      }, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
  }]
}
  subscription: Subscription;
  constructor(private http: HttpClient) { }

  ngOnInit(){
    Highcharts.chart('container', this.options);

    // Set 10 seconds interval to update data again and again
    // const source = interval(10000);

    // // Sample API
    // const apiLink = 'https://api.myjson.com/bins/13lnf4';

    // this.subscription = source.subscribe(val => this.getApiResponse(apiLink).then(
    //   data => {
    //     const updated_normal_data = [];
    //     const updated_abnormal_data = [];
    //     data.forEach(row => {
    //       const temp_row = [
    //         new Date(row.timestamp).getTime(),
    //         row.value
    //       ];
    //       row.Normal === 1 ? updated_normal_data.push(temp_row) : updated_abnormal_data.push(temp_row);
    //     });
    //     this.options.series[0]['data'] = updated_normal_data;
    //     this.options.series[1]['data'] = updated_abnormal_data;
    //     Highcharts.chart('container', this.options);
    //   },
    //   error => {
    //     console.log('Something went wrong.');
    //   })
    // );
  }

  getApiResponse(url) {
    return this.http.get<any>(url, {})
      .toPromise().then(res => {
        return res;
      });
  }
}

