import { TrimOutletNamePipe } from './trim-outlet-name.pipe';

describe('TrimOutletNamePipe', () => {
  it('create an instance', () => {
    const pipe = new TrimOutletNamePipe();
    expect(pipe).toBeTruthy();
  });
});
